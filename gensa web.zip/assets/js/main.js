// select header
// select nav
// select nav trigger

// open - close menu

// header background on scroll

// Initialize Swiper

// Scroll Reveal
